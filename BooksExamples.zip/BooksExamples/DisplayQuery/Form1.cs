﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Entity;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DisplayQuery
{
    /// <summary>
    /// This program uses the books database to make a connection to the titles table. It is then queried with buttons.
    /// </summary>
    /// <Student>Grace Cappella</Student>
    /// <Class>CIS297</Class>
    /// <Semester>Winter 2022</Semester>
    public partial class DisplayTitleQueries : Form
    {
        /// <summary>
        /// Initializes componets of the project
        /// </summary>
        public DisplayTitleQueries()
        {
            InitializeComponent();
        }

        private BooksExamples.BooksEntities dbcontext = new BooksExamples.BooksEntities();

        /// <summary>
        /// Loads the titles table from the database on form load, ordered by ISBN.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Form1_Load(object sender, EventArgs e)
        {
             //load Titles table ordered by ISBN
             dbcontext.Titles
                 .OrderBy(titles => titles.ISBN)
                 .Load();
            //specify datasource for titleBindingSource
            titleBindingSource.DataSource = dbcontext.Titles.Local;
        }

        /// <summary>
        /// Queries the Titles table based on the text in the corresponding textbox. 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void SearchTitles_Click(object sender, EventArgs e)
        {
            titleBindingSource.DataSource = dbcontext.Titles.Local.Where(title => title.Title1.Contains(TitleTextBox.Text)).OrderBy(title => title.ISBN);
            titleBindingSource.MoveFirst();

            bindingNavigatorAddNewItem.Enabled = false;
            bindingNavigatorDeleteItem.Enabled = false;
        }

        /// <summary>
        /// Refreshes the Titles table
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void resetTable_Click(object sender, EventArgs e)
        {
            bindingNavigatorAddNewItem.Enabled = true;
            bindingNavigatorDeleteItem.Enabled = true;

            //load Titles table ordered by ISBN
            dbcontext.Titles
                .OrderBy(title => title.ISBN)
                .Load();
            //specify datasource for titleBindingSource
            titleBindingSource.DataSource = dbcontext.Titles.Local;
        }
    }
}
