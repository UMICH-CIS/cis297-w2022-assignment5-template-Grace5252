﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Entity;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DisplayTable
{
    /// <summary>
    /// This program uses the books database to make a connection to the authors table. It is then queried with buttons.
    /// </summary>
    /// <Student>Grace Cappella</Student>
    /// <Class>CIS297</Class>
    /// <Semester>Winter 2022</Semester>
    public partial class DisplayAuthorsTable : Form
    {
        private bool check = false;

        /// <summary>
        /// Initializes Components of the project, including the form
        /// </summary>
        public DisplayAuthorsTable()
        {
            InitializeComponent();
        }

        //Entity Framework DbContext
        private BooksExamples.BooksEntities dbcontext = new BooksExamples.BooksEntities();

        /// <summary>
        /// On load of the form, the database's data is loaded into DataGridView
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void DisplayAuthorsTable_Load(object sender, EventArgs e)
        {
            if (!check)
            {
                //load Authors table ordered by LastName then FirstName
                dbcontext.Authors
                    .OrderBy(author => author.LastName)
                    .ThenBy(author => author.FirstName)
                    .Load();
                //specify datasource for authorBindingSource
                authorBindingSource.DataSource = dbcontext.Authors.Local;
            }
        }

        /// <summary>
        /// When the database has an operation performed on it, refresh is called
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void authorBindingNavigator_RefreshItems(object sender, EventArgs e)
        {
            if (!check)
            {
                //load Authors table ordered by LastName then FirstName
                dbcontext.Authors
                    .OrderBy(author => author.LastName)
                    .ThenBy(author => author.FirstName)
                    .Load();
                //specify datasource for authorBindingSource
                authorBindingSource.DataSource = dbcontext.Authors.Local;
            }
        }

        /// <summary>
        /// To add an item to the database
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void authorBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            Validate();
            authorBindingSource.EndEdit();
            try
            {
                dbcontext.SaveChanges();
            }
            catch (System.Data.Entity.Validation.DbEntityValidationException)
            {
                MessageBox.Show("FirstName and LastName must contain values", "Entity Validation Exception");
            }
        }

        private void authorDataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        /// <summary>
        /// Button clicked to query the database using the string within its linked textbox
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button1_Click(object sender, EventArgs e)
        {
            check = true;

            authorBindingSource.DataSource = dbcontext.Authors.Local.Where(author => author.LastName.StartsWith(NameTextBox.Text)).OrderBy(author => author.LastName).ThenBy(author => author.FirstName);
            authorBindingSource.MoveFirst();

            bindingNavigatorAddNewItem.Enabled = false;
            bindingNavigatorDeleteItem.Enabled = false;

        }

        /// <summary>
        /// Button used to refresh the table from the database
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ResetTable_Click(object sender, EventArgs e)
        {
            bindingNavigatorAddNewItem.Enabled = true;
            bindingNavigatorDeleteItem.Enabled = true;

            //load Authors table ordered by LastName then FirstName
            dbcontext.Authors
                .OrderBy(author => author.LastName)
                .ThenBy(author => author.FirstName)
                .Load();
            //specify datasource for authorBindingSource
            authorBindingSource.DataSource = dbcontext.Authors.Local;

            check = true;
        }

        private void DisplayAuthorsTable_Load_1(object sender, EventArgs e)
        {

        }
    }
}
